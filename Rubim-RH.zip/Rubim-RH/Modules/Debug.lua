local error = error
local setmetatable = setmetatable
local stringformat = string.format
local globalPulse = 0

local function Class()
    local Class = {}
    Class.__index = Class
    setmetatable(Class, {
        __call = function(self, ...)
            local Object = {}
            setmetatable(Object, self)
            Object:New(...)
            return Object
        end
    })
    return Class
end

local Spell = Class()
function Spell:New(SpellID, SpellType)
    self.SpellID = SpellID
    self.isActive = true
end

local Spells = {
    PrismaticBarrier = 235450,


    ArcanePower = 12042,
    ArcaneBlast = 30451,
    ArcaneBarrage = 44425,
    ArcaneMissiles = 5143,
    ArcaneOrb = 153626,
    PresenceofMind = 205025,
    Clearcasting = 263725,
    FrostNova = 122,
    Evocation = 12051,

    Amplification = 236628,
    RuneofPower = 116011,
    Overpowered = 155147,
    ChargedUp = 205032,
    ArcaneOrb = 153626,
    NetherTempest = 114923,
}
local S = Spells


--Send Argument "gcd" to get gcd
local function CDDuration(spell)
    return TMW.CNDT.Env.CooldownDuration(spell)
end

local function BuffRemains(unitID, spell, source)
    local filter = "HELPFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return select(1, TMW.CNDT.Env.AuraDur(unitID, spell, filter))
end

local function Buffs(unitID, spell, source)
    local filter = "HELPFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"

    if #spell > 1 then
        local found = false
        for i, v in pairs(spell) do
            found = (select(2, TMW.CNDT.Env.AuraDur(unitID, v, filter)) > 0 and true or false)

            if found == true then
                break
            end
        end
        return found
    end

    return (select(2, TMW.CNDT.Env.AuraDur(unitID, spell, filter)) > 0 and true or false)
end

local function Buff(unitID, spell, source)

    local filter = "HELPFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"

    return (select(2, TMW.CNDT.Env.AuraDur(unitID, spell, filter)) > 0 and true or false)
end

local function BuffDuration(unitID, spell, source)
    local filter = "HELPFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return select(2, TMW.CNDT.Env.AuraDur(unitID, spell, filter))
end

local function BuffStack(unitID, spell, source)
    local filter = "HELPFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return TMW.CNDT.Env.AuraStacks(unitID, spell, filter)
end

local function DebuffRemains(unitID, spell, source)
    local filter = "HARMFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return select(1, TMW.CNDT.Env.AuraDur(unitID, spell, filter))
end

local function DebuffDuration(unitID, spell, source)
    local filter = "HARMFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return select(2, TMW.CNDT.Env.AuraDur(unitID, spell, filter))
end

local function DebuffStack(unitID, spell, source)
    local filter = "HARMFUL"

    if source == "Player" then
        filter = filter .. " " .. "PLAYER"
    end

    local unitID = unitID or "Player"
    return TMW.CNDT.Env.AuraStacks(unitID, spell, filter)
end

local function SpellUsable(spell, offset)
    local offset = offset or 0.2
    return IsUsableSpell(spell) and CDDuration(spell) <= offset
end

local function ArcanePowerCharge()
    return UnitPower("Player", Enum.PowerType.ArcaneCharges)
end

local function SpellAvailable(spellID)
    return IsSpellKnown(spellID, true) or IsPlayerSpell(spellID)
end

local function SpellReady(spellID)
    return SpellAvailable(spellID) and CDDuration(spellID) <= 0.2
end

local function SpellCharges(spellID)
    return GetSpellCharges(spellID)
end

local function ManaPct()
    return (UnitPower("Player", 0) / UnitPowerMax("Player", 0)) * 100
end

local function Invisible()
    return Buffs("player", { 114018, 32612, 110959, 198158 })
end

local function findAzerite(spellID)
    local AzeriteItemSlotIDs = { 1, 3, 5 }
    local AzeriteEmpoweredItem = _G.C_AzeriteEmpoweredItem
    local AzeriteItems = {}
    local Item = Item
    local Azerite = 0
    for _, ID in pairs(AzeriteItemSlotIDs) do
        AzeriteItems[ID] = Item:CreateFromEquipmentSlot(ID)
    end

    for _, item in pairs(AzeriteItems) do
        if not item:IsItemEmpty() then
            local itemLoc = item:GetItemLocation()
            if AzeriteEmpoweredItem.IsAzeriteEmpoweredItem(itemLoc) then
                local tierInfos = AzeriteEmpoweredItem.GetAllTierInfo(itemLoc)
                for _, tierInfo in pairs(tierInfos) do
                    for _, powerId in pairs(tierInfo.azeritePowerIDs) do
                        if AzeriteEmpoweredItem.IsPowerSelected(itemLoc, powerId) then
                            local spellIDAzerite = C_AzeriteEmpoweredItem.GetPowerInfo(powerId).spellID
                            if spellID == spellIDAzerite then
                                Azerite = Azerite + 1
                            end
                        end
                    end
                end
            end
        end
    end
    return Azerite
end

function AzeriteRank(spellID)
    return findAzerite(spellID)
end

local function TargetIsEnemy()
    return ReactionUnit("target", "enemy")
end
local mainRot = 0
function mainRotation()

    if not TargetIsEnemy("target", "enemy") then return
        0
    end

    if SpellReady(S.ArcaneOrb) and
            ArcaneBurnPhase() and
            SpellAvailable(153626) and
            ArcanePowerCharge()<4 and
            CombatTime("player")>0
        then
        return S.ArcaneOrb
    end

    if SpellReady(S.NetherTempest) and
            SpellAvailable(114923) and
            ArcanePreCast() and
            DeBuffs("target", 114923, "player")<=3 and -- this debuff
            (
                    ArcaneBurnPhase() or
                            -- ArcanePower + PowerRunic
                            Buffs("player", {12042, 116014}, "player")==0
            ) and
            CombatTime("player")>0
        then
        return S.NetherTempest
    end

    if SpellReady(S.MirrorImage) and
            burst_toggle and
            MySpec(1) and
            ReactionUnit("target", "enemy") and
            SpellAvailable(55342) and
            ArcaneBurnPhase()
            then
        return S.MirrorImage
    end

    if SpellReady(S.PowerRune) and
            CurrentSpeed("player")==0 and
            ReactionUnit("target", "enemy") and
            SpellAvailable(116011) and
            ArcaneBurnPhase() and
            Buffs("player", 116011, "player")==0 -- this buff
        then
        return S.PowerRune
    end

    if SpellReady(S.ArcanePower) and
            burst_toggle and
            ArcaneBurnPhase() then
        return S.ArcanePower
    end




    return 0
end

local mainRot = 0
C_Timer.NewTicker(0.2, function()
    mainRot = mainRotation()
end)

function RotationHelper(icon)



    local spellID = tonumber(icon.Name)
    if icon.Enabled and spellID == mainRot then
        return true
    end
    return false
end