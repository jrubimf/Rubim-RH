
local addonName, addonTable = ...;
local HL = HeroLib;
local Cache = HeroCache;
local Unit = HL.Unit;
local Player = Unit.Player;
local Target = Unit.Target;
local Spell = HL.Spell;
local Item = HL.Item;

local S = RubimRH.Spell[269]

if not Item.Monk then Item.Monk = {}; end
Item.Monk.Windwalker = {
DrinkingHornCover                = Item(137097, {9}),
TheEmperorsCapacitor             = Item(144239, {5}),
KatsuosEclipse                   = Item(137029, {8}),
HiddenMastersForbiddenTouch      = Item(137057, {10}),
}
local I = Item.Monk.Windwalker

local BaseCost = {
[S.BlackoutKick] = (Player:Level() < 12 and 3 or (Player:Level() < 22 and 2 or 1)),
[S.RisingSunKick] = 2,
[S.FistsOfFury] = (I.KatsuosEclipse:IsEquipped() and 2 or 3),
[S.SpinningCraneKick] = 3,
[S.RushingJadeWind] = 1
}

local T202PC, T204PC = HL.HasTier("T20");
local T212PC, T214PC = HL.HasTier("T21");

local EnemyRanges = {"Melee", 8}
local function UpdateRanges()
    for _, i in ipairs(EnemyRanges) do
        HL.GetEnemies(i);
    end
end

local function num(val)
    if val then return 1 else return 0 end
end

local function bool(val)
    return val ~= 0
end


local function APL()
    local Precombat, Aoe, Cd, Sef, Serenity, St
    UpdateRanges()



	if not Player:AffectingCombat() then
		return 0, 462338
	end
	HL.GetEnemies("Melee");
	HL.GetEnemies(8,true);
	HL.GetEnemies(10,true); 
	HL.GetEnemies(30,true);

	if Player:IsChanneling(S.SpinningCraneKick) or Player:IsChanneling(S.FistsOfFury) then
        return 0, "Interface\\Addons\\Rubim-RH\\Media\\channel.tga"
    end

	--actions.precombat=flask
	--actions.precombat+=/food
	--actions.precombat+=/augmentation
	--actions.precombat+=/snapshot_stats
	--actions.precombat+=/potion
	--actions.precombat+=/chi_burst
	--actions.precombat+=/chi_wave

	--actions=auto_attack
	--actions+=/spear_hand_strike,if=target.debuff.casting.react
	--actions+=/touch_of_karma,interval=90,pct_health=0.5,if=!talent.Good_Karma.enabled,interval=90,pct_health=0.5
	--actions+=/touch_of_karma,interval=90,pct_health=1.0
	--actions+=/potion,if=buff.serenity.up|buff.storm_earth_and_fire.up|(!talent.serenity.enabled&trinket.proc.agility.react)|buff.bloodlust.react|target.time_to_die<=60
	--actions+=/touch_of_death,if=target.time_to_die<=9
	if S.TouchOfDeath:IsReady() and Target:TimeToDie() <= 9 then
		S.TouchOfDeath:Cast()
	end

	--actions+=/call_action_list,name=serenity,if=(talent.serenity.enabled&cooldown.serenity.remains<=0)|buff.serenity.up
	if serenity() ~= nil and ((S.Serenity:IsAvailable() and S.Serenity:CooldownRemainsP() <= 0) or Player:BuffP(S.Serenity)) then
		return serenity()
	end

	--actions+=/call_action_list,name=sef,if=!talent.serenity.enabled&(buff.storm_earth_and_fire.up|cooldown.storm_earth_and_fire.charges=2)
	if sef() ~= nil and ((not S.Serenity:IsAvailable() and S.FistsOfFury:CooldownRemainsP() <= 12 and Player:Chi() >= 3 and S.RisingSunKick:CooldownRemainsP() <= 1) or Target:TimeToDie() <= 25 or S.TouchOfDeath:CooldownRemainsP() > 112) then
		return sef()
	end

	--actions+=/call_action_list,name=sef,if=(!talent.serenity.enabled&!equipped.drinking_horn_cover&cooldown.fists_of_fury.remains<=6&chi>=3&cooldown.rising_sun_kick.remains<=1)|target.time_to_die<=15|cooldown.touch_of_death.remains>112&cooldown.storm_earth_and_fire.charges=1
	if sef() ~= nil and ((not S.Serenity:IsAvailable() and not I.DrinkingHornCover:IsEquipped() and S.FistsOfFury:CooldownRemainsP() <= 6 and Player:Chi() >= 3 and S.RisingSunKick:CooldownRemainsP() <= 1) or Target:TimeToDie() <= 15 or S.TouchOfDeath:CooldownRemainsP() > 112 and S.StormEarthAndFire:ChargesP() == 1) then
		return sef()
	end

	--actions+=/call_action_list,name=sef,if=(!talent.serenity.enabled&cooldown.fists_of_fury.remains<=12&chi>=3&cooldown.rising_sun_kick.remains<=1)|target.time_to_die<=25|cooldown.touch_of_death.remains>112&cooldown.storm_earth_and_fire.charges=1
	if sef() ~= nil and ((not S.Serenity:IsAvailable() and S.FistsOfFury:CooldownRemainsP() <= 12 and Player:Chi() >= 3 and S.RisingSunKick:CooldownRemainsP() <= 1) or Target:TimeToDie() <= 25 or S.TouchOfDeath:CooldownRemainsP() > 112 and S.StormEarthAndFire:ChargesP() == 1) then
		return sef()
	end

	--actions+=/call_action_list,name=aoe,if=active_enemies>3
	if aoe() ~= nil and RubimRH.AoEON() and (Cache.EnemiesCount[8] > 3) then
		return aoe()
	end

	--actions+=/call_action_list,name=st,if=active_enemies<=3
	if st() ~= nil and (Cache.EnemiesCount[8] <= 3) then
		return st()
	end

	return 0, 135328
end

RubimRH.Rotation.SetAPL(269, APL);

local function PASSIVE()
	return RubimRH.Shared()
end

RubimRH.Rotation.SetPASSIVE(269, PASSIVE);

